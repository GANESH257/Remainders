create database reminderapp;
use reminderapp;

create table reminders(
	id int auto_increment primary key,
	message varchar(40),
	date datetime
);
