Few points to consider
===========================
- Run create_db.sql on your mysql server. It will create db with name 'reminderapp' and a table with name 'reminders'
- The username for mysql is taken as "root" and password as "". You can change these properties in IDBConstants.java.
- To run the program, execute Main.