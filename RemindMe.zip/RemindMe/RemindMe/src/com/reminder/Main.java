package com.reminder;

import java.util.List;
import java.util.Scanner;

import com.reminder.models.Reminder;

public class Main {

	private static String optionsView = "";

	/**
	 * Its build the options panel. The panel which would contains tasks to add,
	 * update, and delete reminders. This method would be called only once. Once
	 * options are built, they can be readily used.
	 */
	private static void buildOptions() {

		StringBuilder optionBuilder = new StringBuilder();
		optionBuilder.append(" ==================================");
		optionBuilder.append("\n");
		optionBuilder.append("|--------- REMINDER-APP ---------  |");
		optionBuilder.append("\n");
		optionBuilder.append(" ==================================");
		optionBuilder.append("\n");
		optionBuilder.append("1. Add a reminder");
		optionBuilder.append("\n");
		optionBuilder.append("2. Update the reminder");
		optionBuilder.append("\n");
		optionBuilder.append("3. Delete the reminder");
		optionBuilder.append("\n");
		optionBuilder.append("4. Show all reminders");
		optionBuilder.append("\n");
		optionBuilder.append("5. Exit the application");
		optionBuilder.append("\n");
		optionBuilder.append("Your Option: ");

		optionsView = optionBuilder.toString();
	}

	/**
	 * Checks if date string is valid
	 * 
	 * @param date
	 *            The string date to verify
	 * @return if data is valid or not
	 */
	private static Boolean isValidDate(String date) {

		return date.trim().matches("^(\\d){4}-(\\d){2}-(\\d){2} (\\d){2}:(\\d){2}:(\\d){2}$");
	}

	/**
	 * Checks if reminder id is valid
	 * 
	 * @param reminderId
	 *            The reminder id to verify
	 * @return If reminder id is valid or not
	 */
	private static Boolean isValidReminderId(String reminderId) {

		try {
			Integer.parseInt(reminderId);
		} catch (NumberFormatException numberFormatException) {
			return false;
		}
		return true;
	}

	/**
	 * Prints the reminders in formatted way
	 */
	private static void printReminders(List<Reminder> reminders) {

		String format = "|%1$-10s|%2$-45s|%3$-20s|\n";
		System.out.format(format, "Id", "Message", "Date");
		System.out.println("-------------------------------------------------------------------------------");		
		reminders.forEach((reminder) -> {
			System.out.format(format, reminder.getId(), reminder.getMessage(), reminder.getDate());
		});
	}

	/**
	 * Execution starts here
	 */
	public static void main(String[] args) {
		buildOptions();
		Scanner scanner = new Scanner(System.in);
		DatabaseManager databaseManager = new DatabaseManager();

		while (true) { // runs until user exits the app
			System.out.print(optionsView);
			String option = scanner.nextLine().trim();
			if ("1".equals(option)) {
				System.out.print("Message: ");
				String message = scanner.nextLine();
				System.out.print("Date(YYYY-MM-DD HH:MM:SS): ");
				String date = scanner.nextLine();

				if (isValidDate(date)) {
					databaseManager.insertReminder(message, date);
					System.out.println("Reminder Inserted Successfully!!");
				} else {
					System.out.println("Invalid date !!");
				}
			} else if ("2".equals(option)) {
				System.out.print("Reminder ID: ");
				String reminderId = scanner.nextLine();
				System.out.print("Updated Message: ");
				String message = scanner.nextLine();
				System.out.print("Updated Date(YYYY-MM-DD HH:MM:SS): ");
				String date = scanner.nextLine();

				if (isValidDate(date) && isValidReminderId(reminderId)) {
					databaseManager.updateReminder(reminderId, message, date);
					System.out.println("Reminder Updated Successfully!!");
				} else {
					System.out.println("Invalid date/reminderId !!");
				}
			} else if ("3".equals(option)) {
				System.out.print("Reminder ID: ");
				String reminderId = scanner.nextLine();

				if (isValidReminderId(reminderId)) {
					databaseManager.deleteReminder(reminderId);
					System.out.println("Reminder Deleted Successfully!!");
				} else {
					System.out.println("Invalid reminderId !!");
				}
			} else if ("4".equals(option)) {
				List<Reminder> reminders = databaseManager.fetchAllReminders();
				printReminders(reminders);
			} else if ("5".equals(option)) {
				break;
			} else {
				System.out.println("Invalid Option!!");
			}
			System.out.println();
		}
		scanner.close();
	}
}
