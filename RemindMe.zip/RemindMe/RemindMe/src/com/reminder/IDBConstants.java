package com.reminder;

public interface IDBConstants {
	public static final String USERNAME = "root";
	public static final String PASSWORD = "";
}
