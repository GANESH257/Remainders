package com.reminder.models;

/**
 * The class Reminder holds information for any set reminder
 */
public class Reminder {

	/**
	 * The unique identifier of reminder
	 */
	private Integer id;

	/**
	 * The reminder message
	 */
	private String message;

	/**
	 * The reminder date
	 */
	private String date;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
