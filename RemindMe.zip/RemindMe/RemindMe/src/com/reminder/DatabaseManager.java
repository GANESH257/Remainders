package com.reminder;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.reminder.models.Reminder;

public class DatabaseManager {

	/**
	 * The database connection object
	 */
	private Connection connection;

	/**
	 * Instantiating the database manager
	 */
	public DatabaseManager() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/reminderapp", IDBConstants.USERNAME,
					IDBConstants.PASSWORD);
		} catch (Exception e) {
			System.out.println("Database connection failed!!");
		}
	}

	/**
	 * Inserts the reminder in the DB
	 * 
	 * @param message
	 *            The message of reminder
	 * @param date
	 *            The date set for reminder
	 */
	public void insertReminder(String message, String date) {

		try {
			Statement statement = connection.createStatement();
			String insertQuery = "insert into reminders(message, date) values(\"" + message + "\",\"" + date + "\")";
			statement.executeUpdate(insertQuery);
		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			System.out.println("Data insertion failed!!");
		}
	}

	/**
	 * Updates reminder (if exists)
	 * 
	 * @param reminderId
	 *            The id of reminder to udpdate
	 * @param message
	 *            The updated message
	 * @param date
	 *            The updated date
	 */
	public void updateReminder(String reminderId, String message, String date) {

		try {
			Statement statement = connection.createStatement();
			String updateQuery = "update reminders set message=\"" + message + "\", date=\"" + date + "\" where id="
					+ reminderId;
			statement.executeUpdate(updateQuery);
		} catch (SQLException sqlException) {
			System.out.println("Data updation failed!!");
		}
	}

	/**
	 * Deletes reminder of specified id
	 * 
	 * @param reminderId
	 *            The id of reminder to delete
	 */
	public void deleteReminder(String reminderId) {

		try {
			Statement statement = connection.createStatement();
			String updateQuery = "delete from reminders where id=" + reminderId;
			statement.executeUpdate(updateQuery);
		} catch (SQLException sqlException) {
			System.out.println("Data deletion failed!!");
		}
	}

	/**
	 * Fetches all reminders present in DB
	 */
	public List<Reminder> fetchAllReminders() {

		List<Reminder> reminders = new ArrayList<>();
		try {
			Statement statement = connection.createStatement();
			String query = "select * from reminders";
			ResultSet resultSet = statement.executeQuery(query);
			while (resultSet.next()) {
				Reminder reminder = new Reminder();
				reminder.setId(Integer.parseInt(resultSet.getString(1)));
				reminder.setMessage(resultSet.getString(2));
				reminder.setDate(resultSet.getString(3));
				reminders.add(reminder);
			}
		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			System.out.println("Data retrieval failed!!");
		}
		return reminders;
	}
}
